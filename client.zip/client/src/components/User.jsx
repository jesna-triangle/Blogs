import React from 'react';
import { NavLink } from 'react-router-dom';

// Sample data for testing
const userData = {
    userId: "671217d887106062d400524b", 
    username: "Roger Dennis",
    email: "roger33@mail.com",
    followers: [""],
    // Add any other necessary fields
  };
  
  // Usage in a parent component
  <UsersPage userData={userData} />
  