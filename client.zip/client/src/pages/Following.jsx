import React from 'react'

const Following = () => {
  return (
    <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt, maxime similique nobis sapiente blanditiis nulla quaerat labore ex mollitia quos quibusdam, fuga, fugit deleniti adipisci quia autem enim cupiditate libero!</div>
  )
}

export default Following