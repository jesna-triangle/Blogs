const express = require('express')
const { postBlog, getAllBlogs, updateBlog, deleteBlog, } = require('../blogs/blogController')
const { authUser } = require('../../middleware/authmiddleware')

const router = express.Router()

router.route('/').post(authUser, postBlog).get(getAllBlogs)
router.route("/:blogId").put(authUser,updateBlog).delete(deleteBlog);
module.exports = router