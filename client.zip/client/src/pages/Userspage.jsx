import React, { useState, useEffect  } from 'react';
import BlogCard from '../components/Blogcard';
import axios from 'axios';

const UsersPage = ({ userData }) => {
    const [isFollowing, setIsFollowing] = useState(false)

    const handleFollowToggle = () => {
        setIsFollowing(!isFollowing); 
    };

    return (
        <div className="user-page">
            <div className="user-details">
                <h2>Sample User</h2>
                <p>Email: email@mail.com</p>
            
                <button className="follow-btn" onClick={handleFollowToggle}>
                    {isFollowing ? 'Unfollow' : 'Follow'}
                </button>
            </div>

            <div className="user-blogs">
                <h3>User's Blogs</h3>
                <ul className="blog-list">
                    <BlogCard />
                </ul>
            </div>
        </div>
    );
};

export default UsersPage;

