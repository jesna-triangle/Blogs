import React from 'react';

const BlogPage = () => {

  return (
    <div className="blog-page">
      <h1 className="blog-title">Title</h1>
      <p className="blog-author">By Author </p>
      <div className="blog-content">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Asperiores aspernatur aut perferendis illo soluta dolorem deleniti sapiente necessitatibus eos dolorum quibusdam veritatis accusantium aperiam, ipsum at repellendus possimus suscipit! Eos?
      </div>
    </div>
  );
};

export default BlogPage;
