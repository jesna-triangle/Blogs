import React from 'react'
import BlogCard from '../components/Blogcard'

const Home = () => {
  return (
    <div><BlogCard/></div>
  )
}

export default Home
