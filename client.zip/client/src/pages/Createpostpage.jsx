import React, { useState } from 'react';

const CreatePostPage = () => {
    const handleSubmit = async (e) => {
        e.preventDefault();
    };

    return (
        <div className="create-post-page">
            <div className="create-post-container">
                <h2>Create a New Post</h2>
                {/* {successMessage && <p className="success">{successMessage}</p>} */}

                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="title">Title:</label>
                        <input
                            type="text"
                            id="title"
                            //   onChange={(e) => setTitle(e.target.value)}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="category">Category:</label>hbngfy
                        <select id="category" value="{category} "
                        // onChange={(e) => setCategory(e.target.value)} 
                        required>
                            <option value="" disabled>Select category</option>
                            <option value="technology">Technology</option>
                            <option value="health">Health</option>
                            <option value="lifestyle">Lifestyle</option>
                            <option value="education">Education</option>
                        </select>
                    </div>

                    <div className="form-group">
                        <label htmlFor="description">Description:</label>
                        <textarea
                            id="description"
                            // onChange={(e) => setDescription(e.target.value)}
                            rows="5"
                            required
                        />
                    </div>

                    <button type="submit" className="submit-btn">Create Post</button>
                </form>
            </div>
        </div>
    );
};

export default CreatePostPage;
