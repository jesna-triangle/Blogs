import React from 'react';
import { NavLink } from 'react-router-dom';

const BlogCard = ({ blog, userData }) => {
  return (
    <>
    
    <div className="blog-card ">
      <div className="blog-card-content ">
        <h2 className="blog-title">Title</h2>
        <p className="blog-author">By author</p>
        <NavLink to={`/blog/$`} className="read-more-link">
          Read More
        </NavLink>
      </div>
    </div>
     <div className="blog-card">
     <div className="blog-card-content ">
       <h2 className="blog-title">Title</h2>
       <p className="blog-author">By author</p>
       <NavLink to={`/blog/$`} className="read-more-link">
         Read More
       </NavLink>
     </div>
   </div>
   </>
  );
};

export default BlogCard;
